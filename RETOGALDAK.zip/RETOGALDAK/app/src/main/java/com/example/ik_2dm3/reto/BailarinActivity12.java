package com.example.ik_2dm3.reto;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.Scanner;

import static com.example.ik_2dm3.reto.Bailefinal16.REQUEST_ANTERIOR;

public class BailarinActivity12 extends AppCompatActivity {

    private ImageButton butSiguiente;
    private ImageButton butAtras;
    private TextView txtBailarin;
    public String idioma;

    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bailarin);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        idioma = getIntent().getStringExtra("idioma");

        Resources res = getResources();
        InputStream is = res.openRawResource(R.raw.json);
        Scanner scanner = new Scanner(is);
        StringBuilder builder = new StringBuilder();
        while(scanner.hasNextLine()){
            builder.append(scanner.nextLine());
        }
        parseJson(builder.toString());

        butSiguiente = findViewById(R.id.proximo);
        butAtras=findViewById(R.id.previo);


        butSiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(BailarinActivity12.this, Bailarin2Activity13.class);
                i.putExtra("idioma",idioma);
                startActivity(i);
            }
        });
        butAtras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(BailarinActivity12.this, Maps.class);
                i.putExtra("idioma",idioma);
                i.putExtra("lugar", "monumento");
                startActivityForResult(i, REQUEST_ANTERIOR);
            }
        });




        //obtenemos el control VideoView
        VideoView videoView = (VideoView)findViewById(R.id.vidUno);
        //Establecemos la Uri del Video
        Uri uri = Uri.parse("android.resource://"+getPackageName()+"/"+ R.raw.bailarin);

        MediaController mc = new MediaController(this);
        videoView.setMediaController(mc);

        //Asignamos la Uri al COntrol VideoView
        videoView.setVideoURI(uri);
        //Iniciamos Video
        videoView.start();
    }

    private void parseJson (String s){
        TextView txtBailarin = (TextView) findViewById(R.id.txtBailarin);
        StringBuilder builder = new StringBuilder();
        try{
            JSONObject root = new JSONObject(s);
            JSONObject main = root.getJSONObject("estatua");
            if(idioma.equals("castellano")){
                builder.append(main.getString("textocastellano"));
            }
            else{
                builder.append(main.getString("textoeuskera"));
            }
        }catch(JSONException e){
            e.printStackTrace();
        }
        txtBailarin.setText(builder.toString());
    }
}
