package com.example.ik_2dm3.reto;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.Scanner;

public class Iglesia5 extends AppCompatActivity {

    private Button btnaudio;
    private ImageButton btnsiguiente;
    private ImageButton btnanterior;
    public MediaPlayer audio;
    public String idioma;

    private static  final int REQUEST_ANTERIOR=0;
    private static  final int REQUEST_SIGUIENTE=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iglesia);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        idioma = getIntent().getStringExtra("idioma");

        Resources res = getResources();
        InputStream is = res.openRawResource(R.raw.json);
        Scanner scanner = new Scanner(is);
        StringBuilder builder = new StringBuilder();
        while(scanner.hasNextLine()){
            builder.append(scanner.nextLine());
        }
        parseJson(builder.toString());

        btnaudio=(Button) findViewById(R.id.btnaudio);
        btnanterior=(ImageButton) findViewById(R.id.btnanterior);
        btnsiguiente=(ImageButton) findViewById(R.id.btnsiguiente);
        //audio=MediaPlayer.create(this,R.raw.iglesiacast);

        //audio.start();

        btnaudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                audio.start();


            }
        });

        btnsiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                audio.stop();
                Intent i = new Intent(Iglesia5.this,Gargola6.class);
                i.putExtra("idioma",idioma);
                startActivityForResult(i, REQUEST_SIGUIENTE);
            }
        });

        btnanterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                audio.stop();
                Intent i = new Intent(Iglesia5.this,Maps.class);
                i.putExtra("idioma",idioma);
                i.putExtra("lugar", "ayunta");
                startActivityForResult(i, REQUEST_ANTERIOR);
            }
        });

    }

    public void parseJson (String s){
        //audio

        StringBuilder sbuilder = new StringBuilder();
        try{
            JSONObject root = new JSONObject(s);
            JSONObject path = root.getJSONObject("iglesia");
            if(idioma.equals("castellano")){
                sbuilder.append(path.getString("audiocastellano"));
            }
            else{
                sbuilder.append(path.getString("audioeuskera"));
            }
        }catch(JSONException e){
            e.printStackTrace();
        }
        String sonido = sbuilder.toString();
        int y = getResources().getIdentifier(sonido,"raw",this.getPackageName());

        audio = MediaPlayer.create(this, y);
        audio.start();
    }
}
