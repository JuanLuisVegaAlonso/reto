package com.example.ik_2dm3.reto;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.Scanner;

import static com.example.ik_2dm3.reto.Bailefinal16.REQUEST_SIGUIENTE;


public class Instrucciones2 extends AppCompatActivity {

    private MediaPlayer instrucciones;
    private ImageButton butActualizar;
    private ImageButton btnsiguiente;
    private String idioma;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instrucciones);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        idioma = getIntent().getStringExtra("idioma");

        Resources res = getResources();
        InputStream is = res.openRawResource(R.raw.json);
        Scanner scanner = new Scanner(is);
        StringBuilder builder = new StringBuilder();
        while(scanner.hasNextLine()){
            builder.append(scanner.nextLine());
        }
        parseJson(builder.toString());

        butActualizar = (ImageButton) findViewById(R.id.btnActualizar);
        btnsiguiente=findViewById(R.id.proximo);






        butActualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                instrucciones.start();
            }
        });

        btnsiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                instrucciones.stop();
                Intent i = new Intent(Instrucciones2.this, Ayuntamiento3.class);
                i.putExtra("idioma",idioma);
                startActivityForResult(i, REQUEST_SIGUIENTE);
            }
        });

    }

    public void parseJson (String s){
        //fondo
        ConstraintLayout clayout = (ConstraintLayout) findViewById(R.id.clayout);
        StringBuilder builder = new StringBuilder();
        try{
            JSONObject root = new JSONObject(s);
            JSONObject path = root.getJSONObject("instrucciones");
            if(idioma.equals("castellano")){
                builder.append(path.getString("fotocastellano"));
            }
            else{
                builder.append(path.getString("fotoeuskera"));
            }
        }catch(JSONException e){
            e.printStackTrace();
        }


        String image = builder.toString();
        int x = getResources().getIdentifier(image, "drawable",this.getPackageName());
        clayout.setBackgroundResource(x);


        //audio

        StringBuilder sbuilder = new StringBuilder();
        try{
            JSONObject root = new JSONObject(s);
            JSONObject path = root.getJSONObject("instrucciones");
            if(idioma.equals("castellano")){
                sbuilder.append(path.getString("audiocastellano"));
            }
            else{
                sbuilder.append(path.getString("audioeuskera"));
            }
        }catch(JSONException e){
            e.printStackTrace();
        }
        String audio = sbuilder.toString();
        int y = getResources().getIdentifier(audio,"raw",this.getPackageName());
        Log.d(builder.toString(),y+"");

        instrucciones = MediaPlayer.create(this, y);
        instrucciones.start();
    }
}

