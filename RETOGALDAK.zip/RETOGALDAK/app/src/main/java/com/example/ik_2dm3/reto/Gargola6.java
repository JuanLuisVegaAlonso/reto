package com.example.ik_2dm3.reto;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.InputStream;
import java.util.Scanner;

public class Gargola6 extends AppCompatActivity {

    private Button btncamara;
    private ImageButton btnanterior;
    private ImageButton btnsiguiente;
    private ImageView ivcamara;
    private Bitmap foto;
    private String idioma;
    private File filename;

    private static final int REQUEST_ANTERIOR=0;
    private static final int REQUEST_SIGUIENTE=1;
    private static final int REQUEST_FOTO=2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gargola);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        idioma = getIntent().getStringExtra("idioma");

        Resources res = getResources();
        InputStream is = res.openRawResource(R.raw.json);
        Scanner scanner = new Scanner(is);
        StringBuilder builder = new StringBuilder();
        while(scanner.hasNextLine()){
            builder.append(scanner.nextLine());
        }
        parseJson(builder.toString());

        btnanterior = (ImageButton) findViewById(R.id.btnanterior);
        btnsiguiente = (ImageButton) findViewById(R.id.btnsiguiente);
        btncamara = (Button) findViewById(R.id.btncamara);






        btnanterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Gargola6.this, Iglesia5.class);
                i.putExtra("idioma",idioma);
                startActivityForResult(i, REQUEST_ANTERIOR);
            }
        });

        btncamara.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent takeFotoIntent = new Intent((MediaStore.ACTION_IMAGE_CAPTURE));
                startActivityForResult(takeFotoIntent, REQUEST_FOTO);
            }
        });



    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data){

        if (requestCode == REQUEST_FOTO && resultCode == RESULT_OK) {
            foto = (Bitmap) data.getExtras().getParcelable("data");



            Save savefile = new Save();
            savefile.SaveImage(this, foto, "Gargola6");
            btnsiguiente.setEnabled(true);
            btnsiguiente.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(Gargola6.this, Maps.class);
                    i.putExtra("idioma",idioma);
                    i.putExtra("lugar","iglesia");
                    startActivityForResult(i, REQUEST_SIGUIENTE);
                }
            });

        }


    }

    private void parseJson (String s){
        TextView tv = (TextView) findViewById(R.id.tv);
        StringBuilder builder = new StringBuilder();
        try{
            JSONObject root = new JSONObject(s);
            JSONObject main = root.getJSONObject("gargola");
            if(idioma.equals("castellano")){
                builder.append(main.getString("textocastellano"));
            }
            else{
                builder.append(main.getString("textoeuskera"));
            }
        }catch(JSONException e){
            e.printStackTrace();
        }
        tv.setText(builder.toString());
    }


}




