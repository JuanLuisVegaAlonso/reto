package com.example.ik_2dm3.reto;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.util.Scanner;
import java.util.UUID;

import static com.example.ik_2dm3.reto.Bailefinal16.REQUEST_SIGUIENTE;

public class DibujoActivity extends AppCompatActivity implements View.OnClickListener{
    ImageButton negro;
    ImageButton blanco;
    ImageButton rojo;
    ImageButton verde;
    ImageButton azul;
    private static lienzo lienzo;
    float ppequeno;
    float pmediano;
    float pgrande;
    float bpequeno;
    float bmediano;
    float bgrande;
    float pdefecto;
    ImageButton trazo;
    ImageButton anadir;
    ImageButton borrar;
    ImageButton guardar;
    String idioma;
    String activar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dibujo);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        idioma = getIntent().getStringExtra("idioma");

        Resources res = getResources();
        InputStream is = res.openRawResource(R.raw.json);
        Scanner scanner = new Scanner(is);
        StringBuilder builder = new StringBuilder();
        while(scanner.hasNextLine()){
            builder.append(scanner.nextLine());
        }


        negro = (ImageButton)findViewById(R.id.colornegro);
        blanco = (ImageButton)findViewById(R.id.colorblanco);
        rojo = (ImageButton)findViewById(R.id.colorrojo);
        verde = (ImageButton)findViewById(R.id.colorverde);
        azul = (ImageButton)findViewById(R.id.colorazul);
        trazo = (ImageButton)findViewById(R.id.trazo);
        anadir = (ImageButton)findViewById(R.id.anadir);
        borrar = (ImageButton)findViewById(R.id.borrar);
        guardar = (ImageButton)findViewById(R.id.guardar);

        negro.setOnClickListener(this);
        blanco.setOnClickListener(this);
        rojo.setOnClickListener(this);
        verde.setOnClickListener(this);
        azul.setOnClickListener(this);
        trazo.setOnClickListener(this);
        anadir.setOnClickListener(this);
        borrar.setOnClickListener(this);
        guardar.setOnClickListener(this);

        lienzo = (lienzo)findViewById(R.id.lienzo);

        ppequeno= 10;
        pmediano= 30;
        pgrande= 60;

        bpequeno = 80;
        bmediano = 140;
        bgrande = 200;

        pdefecto= pmediano;

    }



    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        String color = null;


        switch (v.getId()){
            case R.id.colornegro:
                color = v.getTag().toString();
                lienzo.setColor(color);
                break;
            case R.id.colorblanco:
                color = v.getTag().toString();
                lienzo.setColor(color);
                break;
            case R.id.colorazul:
                color = v.getTag().toString();
                lienzo.setColor(color);
                break;
            case R.id.colorverde:
                color = v.getTag().toString();
                lienzo.setColor(color);
                break;
            case R.id.colorrojo:
                color = v.getTag().toString();
                lienzo.setColor(color);
                break;
            case R.id.trazo:

                final Dialog tamanopunto = new Dialog(this);
                tamanopunto.setTitle("Tamaño del punto:");
                tamanopunto.setContentView(R.layout.tamano_punto);
                //listen for clicks on tamaños de los botones
                TextView smallBtn = (TextView)tamanopunto.findViewById(R.id.tpequeno);
                smallBtn.setOnClickListener(new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        lienzo.setBorrado(false);
                        lienzo.setTamanyoPunto(ppequeno);

                        tamanopunto.dismiss();
                    }
                });
                TextView mediumBtn = (TextView)tamanopunto.findViewById(R.id.tmediano);
                mediumBtn.setOnClickListener(new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        lienzo.setBorrado(false);
                        lienzo.setTamanyoPunto(pmediano);

                        tamanopunto.dismiss();
                    }
                });
                TextView largeBtn = (TextView)tamanopunto.findViewById(R.id.tgrande);
                largeBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        lienzo.setBorrado(false);
                        lienzo.setTamanyoPunto(pgrande);

                        tamanopunto.dismiss();
                    }
                });
                //show and wait for user interaction
                tamanopunto.show();


                break;
            case R.id.anadir:

                if(idioma.equals("castellano")) {
                    AlertDialog.Builder newDialog = new AlertDialog.Builder(this);
                    if (idioma.equals("castellano"))
                        newDialog.setTitle("Nuevo Dibujo");
                    newDialog.setMessage("¿Comenzar nuevo dibujo (perderás el dibujo actual)?");
                    newDialog.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {

                            lienzo.NuevoDibujo();
                            dialog.dismiss();
                        }
                    });
                    newDialog.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                    newDialog.show();
                }
                else{
                    AlertDialog.Builder newDialog = new AlertDialog.Builder(this);
                    newDialog.setTitle("Marrazki Berria");
                    newDialog.setMessage("Marrazki berria hasi? (Uneko marrazkia galduko duzu)");
                    newDialog.setPositiveButton("Bai", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {

                            lienzo.NuevoDibujo();
                            dialog.dismiss();
                        }
                    });
                    newDialog.setNegativeButton("Ez", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                    newDialog.show();
                }
                break;
            case R.id.borrar:

                final Dialog borrarpunto = new Dialog(this);
                borrarpunto.setTitle("Tamaño de borrado:");
                borrarpunto.setContentView(R.layout.tamano_punto);
                //listen for clicks on tamaños de los botones
                TextView smallBtnBorrar = (TextView)borrarpunto.findViewById(R.id.tpequeno);
                smallBtnBorrar.setOnClickListener(new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        lienzo.setBorrado(true);
                        lienzo.setTamanyoPunto(bpequeno);

                        borrarpunto.dismiss();
                    }
                });
                TextView mediumBtnBorrar = (TextView)borrarpunto.findViewById(R.id.tmediano);
                mediumBtnBorrar.setOnClickListener(new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        lienzo.setBorrado(true);
                        lienzo.setTamanyoPunto(bmediano);

                        borrarpunto.dismiss();
                    }
                });
                TextView largeBtnBorrar = (TextView)borrarpunto.findViewById(R.id.tgrande);
                largeBtnBorrar.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        lienzo.setBorrado(true);
                        lienzo.setTamanyoPunto(bgrande);

                        borrarpunto.dismiss();
                    }
                });
                //show and wait for user interaction
                borrarpunto.show();


                break;
            case R.id.guardar:
                if(idioma.equals("castellano")) {
                    AlertDialog.Builder salvarDibujo = new AlertDialog.Builder(this);
                    salvarDibujo.setTitle("Salvar dibujo");
                    salvarDibujo.setMessage("¿Salvar Dibujo a la galeria?");
                    salvarDibujo.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {

                            //Salvar dibujo
                            lienzo.setDrawingCacheEnabled(true);
                            //attempt to save
                            String imgSaved = MediaStore.Images.Media.insertImage(
                                    getContentResolver(), lienzo.getDrawingCache(),
                                    UUID.randomUUID().toString() + ".jpg", "drawing");
                            //Mensaje de todo correcto
                            if (imgSaved != null) {

                                Toast savedToast = Toast.makeText(getApplicationContext(),
                                        "¡Dibujo salvado en la galeria!", Toast.LENGTH_SHORT);
                                savedToast.show();
                                Intent i = new Intent(DibujoActivity.this, Deposito8.class);
                                i.putExtra("idioma", idioma);
                                startActivityForResult(i, REQUEST_SIGUIENTE);
                            } else {
                                Toast unsavedToast = Toast.makeText(getApplicationContext(),
                                        "¡Error! La imagen no ha podido ser salvada.", Toast.LENGTH_SHORT);
                                unsavedToast.show();

                            }
                            lienzo.destroyDrawingCache();


                        }
                    });
                    salvarDibujo.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                    salvarDibujo.show();

                    break;
                }
                else{
                    AlertDialog.Builder salvarDibujo = new AlertDialog.Builder(this);
                    salvarDibujo.setTitle("Marrazkia gordetzea");
                    salvarDibujo.setMessage("Marrazkirik galerian gordetzea?");
                    salvarDibujo.setPositiveButton("Bai", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {

                            //Salvar dibujo
                            lienzo.setDrawingCacheEnabled(true);
                            //attempt to save
                            String imgSaved = MediaStore.Images.Media.insertImage(
                                    getContentResolver(), lienzo.getDrawingCache(),
                                    UUID.randomUUID().toString() + ".jpg", "drawing");
                            //Mensaje de todo correcto
                            if (imgSaved != null) {

                                Toast savedToast = Toast.makeText(getApplicationContext(),
                                        "Galerian gordetuta!", Toast.LENGTH_SHORT);
                                savedToast.show();
                                Intent i = new Intent(DibujoActivity.this, Deposito8.class);
                                i.putExtra("idioma", idioma);


                            } else {
                                Toast unsavedToast = Toast.makeText(getApplicationContext(),
                                        "¡Error! La imagen no ha podido ser salvada.", Toast.LENGTH_SHORT);
                                unsavedToast.show();

                            }
                            lienzo.destroyDrawingCache();


                        }
                    });
                    salvarDibujo.setNegativeButton("Ezeztatzea", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    });
                    salvarDibujo.show();

                    break;
                }
            default:

                break;
        }
    }
}

