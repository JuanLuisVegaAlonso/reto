package com.example.ik_2dm3.reto;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.location.Location;
import android.location.LocationManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.maps.android.kml.KmlLayer;


import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

import org.json.JSONException;
import org.json.JSONObject;

public class Maps extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    public Button btnAtras;
    public Button btnSiguiente;
    public boolean hilo;
    public boolean correcto;

    private static final int REQUEST_ANTERIOR = 0;
    private static final int REQUEST_SIGUIENTE = 1;
    private static final int REQUEST_LOCATION = 2;
    String idioma, kml, lugar;
    double latitud, longitud, latactual, longactual, nextlat, nextlong;
    int y;
    LocationManager locationManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        idioma = getIntent().getStringExtra("idioma");
        lugar = getIntent().getStringExtra("lugar");
        if (lugar.equals("ayunta")) {
            Log.d("aaaaaaaaaaaaaaaaaaaaaaa", lugar);
        }
        btnAtras = (Button) findViewById(R.id.previo);
        btnSiguiente = (Button) findViewById(R.id.proximo);
        hilo=true;
        Hilo();


        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        Resources res = getResources();
        InputStream is = res.openRawResource(R.raw.json);
        Scanner scanner = new Scanner(is);
        StringBuilder builder = new StringBuilder();
        while (scanner.hasNextLine()) {
            builder.append(scanner.nextLine());
        }
        parseJson(builder.toString());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


        btnAtras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (lugar.equals("ayunta")) {
                    Intent i = new Intent(Maps.this, Ayuntamiento3.class);
                    i.putExtra("idioma", idioma);
                    startActivityForResult(i, REQUEST_ANTERIOR);
                }
                if (lugar.equals("iglesia")) {
                    Intent i = new Intent(Maps.this, Gargola6.class);
                    i.putExtra("idioma", idioma);
                    startActivityForResult(i, REQUEST_ANTERIOR);
                }
                if (lugar.equals("deposito")) {
                    Intent i = new Intent(Maps.this, Deposito8.class);
                    i.putExtra("idioma", idioma);
                    startActivityForResult(i, REQUEST_ANTERIOR);
                }
                if (lugar.equals("monumento")) {
                    Intent i = new Intent(Maps.this, Estatua10.class);
                    i.putExtra("idioma", idioma);
                    startActivityForResult(i, REQUEST_ANTERIOR);
                }

            }
        });

        btnSiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getLocation();
                Log.d("prueba", "curentlat: " + latactual + " currentlong: " + longactual + " nextlat: " + nextlat + " nextlong" + lugar + ": " + nextlong);
                if (correcto==true){
                    hilo=false;
                    if (lugar.equals("ayunta")) {
                        Intent i = new Intent(Maps.this, Iglesia5.class);
                        i.putExtra("idioma", idioma);
                        startActivityForResult(i, REQUEST_SIGUIENTE);
                    }
                    if (lugar.equals("iglesia")) {
                        Intent i = new Intent(Maps.this, Deposito8.class);
                        i.putExtra("idioma", idioma);
                        startActivityForResult(i, REQUEST_SIGUIENTE);
                    }
                    if (lugar.equals("deposito")) {
                        Intent i = new Intent(Maps.this, Estatua10.class);
                        i.putExtra("idioma", idioma);
                        startActivityForResult(i, REQUEST_SIGUIENTE);
                    }
                    if (lugar.equals("monumento")) {
                        Intent i = new Intent(Maps.this, BailarinActivity12.class);
                        i.putExtra("idioma", idioma);
                        startActivityForResult(i, REQUEST_SIGUIENTE);
                    }
                } else {
                    if (idioma.equals("castellano")) {
                        Toast.makeText(getApplicationContext(), "¡Estas muy lejos!", Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(getApplicationContext(), "Urrun zaude!", Toast.LENGTH_SHORT).show();

                    }
                }


            }
        });

    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */



    void getLocation() {
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_LOCATION);

        }
        else{
            Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if(location != null)
            {
                latactual = new Double(location.getLatitude());
                longactual = new Double(location.getLongitude());
            }

        }
    }



        @Override
        public void onMapReady(GoogleMap googleMap) {
            mMap = googleMap;

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }

            CameraPosition cameraPosition = new CameraPosition.Builder()
                    .target(new LatLng(latitud, longitud))      // Sets the center of the map to location user
                    .zoom(17)                   // Sets the zoom
                    .build();                   // Creates a CameraPosition from the builder
            mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
            mMap.getUiSettings().setMapToolbarEnabled(false);

            mMap.setMyLocationEnabled(true);


        try {
            KmlLayer layer = new KmlLayer(mMap, y, getApplicationContext());
            layer.addLayerToMap();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        }

    }

    public void parseJson(String s) {
        StringBuilder builder = new StringBuilder();
        try {
            JSONObject root = new JSONObject(s);
            JSONObject path = root.getJSONObject("maps");
            builder.append(path.getString("kml" + lugar));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        kml = builder.toString();
        y = getResources().getIdentifier(kml, "raw", this.getPackageName());
        StringBuilder builderlon = new StringBuilder();

        try {
            JSONObject root = new JSONObject(s);
            JSONObject path = root.getJSONObject("maps");
            builderlon.append(path.getString("long" + lugar));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        longitud = Double.parseDouble(builderlon.toString());

        StringBuilder builderlat = new StringBuilder();
        try {
            JSONObject root = new JSONObject(s);
            JSONObject path = root.getJSONObject("maps");
            builderlat.append(path.getString("lat" + lugar));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        latitud = Double.parseDouble(builderlat.toString());

        TextView tvmap = (TextView) findViewById(R.id.tvmap);
        StringBuilder buildert = new StringBuilder();
        try {
            JSONObject root = new JSONObject(s);
            JSONObject path = root.getJSONObject("maps");

            if (idioma.equals("castellano")) {
                buildert.append(path.getString(lugar + "cast"));
            } else {
                buildert.append(path.getString(lugar + "eusk"));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        tvmap.setText(buildert.toString());

        StringBuilder buildernla = new StringBuilder();
        try {
            JSONObject root = new JSONObject(s);
            JSONObject path = root.getJSONObject("maps");

            buildernla.append(path.getString("nextlat" + lugar));

        } catch (JSONException e) {
            e.printStackTrace();
        }
        nextlat = Double.parseDouble(buildernla.toString());

        StringBuilder buildernlo = new StringBuilder();
        try {
            JSONObject root = new JSONObject(s);
            JSONObject path = root.getJSONObject("maps");

            buildernlo.append(path.getString("nextlong" + lugar));

        } catch (JSONException e) {
            e.printStackTrace();
        }
        nextlong = Double.parseDouble(buildernlo.toString());
    }

    void Hilo(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (hilo) {
                    getLocation();
                    if (latactual <= (nextlat + 0.0005) && latactual >= (nextlat - 0.0005) && longactual >= (nextlong - 0.0005) && longactual <= (nextlong + 0.0005)) {
                        correcto = true;
                        Log.d("correcto", "correcto");
                    } else {
                        Log.d("correcto", "curentlat: " + latactual + " currentlong: " + longactual + " nextlat: " + nextlat + " nextlong" + lugar + ": " + nextlong);
                        correcto = false;
                    }
                }
            }
        }).start();
    }



}
