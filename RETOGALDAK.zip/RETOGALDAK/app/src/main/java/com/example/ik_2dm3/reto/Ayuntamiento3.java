package com.example.ik_2dm3.reto;

import android.Manifest;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.Scanner;

public class Ayuntamiento3 extends AppCompatActivity {

    private ImageButton btnsiguiente;
    private ImageButton btnanterior;
    private Button btnalcalde;
    private Button btnbombero;
    private Button btnsecretaria;
    private Button btncocinero;
    private Button btncartero;
    private Button btnaudio;
    private Boolean alcalde=false;
    private Boolean cocinero=false;
    private Boolean secretaria=false;
    private Boolean cartero=false;
    private Boolean bombero=false;
    public MediaPlayer audio;
    private String idioma;

    private static  final int REQUEST_ANTERIOR=0;
    private static  final int REQUEST_SIGUIENTE=1;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ayuntamiento);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        idioma = getIntent().getStringExtra("idioma");

        Resources res = getResources();
        InputStream is = res.openRawResource(R.raw.json);
        Scanner scanner = new Scanner(is);
        StringBuilder builder = new StringBuilder();
        while(scanner.hasNextLine()){
            builder.append(scanner.nextLine());
        }
        parseJson(builder.toString());

        //audio=MediaPlayer.create(this,R.raw.ayuntacast);
        btnalcalde=(Button) findViewById(R.id.btnalcalde);
        btnbombero=(Button) findViewById(R.id.btnbombero);
        btncartero=(Button) findViewById(R.id.btncartero);
        btncocinero=(Button) findViewById(R.id.btncocinero);
        btnsecretaria=(Button) findViewById(R.id.btnsecretaria);
        btnanterior=(ImageButton) findViewById(R.id.btnanterior);
        btnsiguiente=(ImageButton) findViewById(R.id.btnsiguiente);
        btnaudio=(Button) findViewById(R.id.btnaudio);



        //audio.start();

        btnalcalde.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(alcalde==false){
                    alcalde=true;
                    btnalcalde.setBackgroundResource(R.drawable.alcalde2);
                }
                else if(alcalde==true){
                    alcalde=false;
                    btnalcalde.setBackgroundResource(R.drawable.alcalde1);
                }
            }
        });

        btnbombero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(bombero==false){
                    bombero=true;
                    btnbombero.setBackgroundResource(R.drawable.bombero2);
                }
                else if(bombero==true){
                    bombero=false;
                    btnbombero.setBackgroundResource(R.drawable.bombero1);
                }
            }
        });

        btncartero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cartero==false){
                    cartero=true;
                    btncartero.setBackgroundResource(R.drawable.cartero2);
                }
                else if(cartero==true){
                    cartero=false;
                    btncartero.setBackgroundResource(R.drawable.cartero1);
                }
            }
        });

        btncocinero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cocinero==false){
                    cocinero=true;
                    btncocinero.setBackgroundResource(R.drawable.cocinero2);
                }
                else if(cocinero==true){
                    cocinero=false;
                    btncocinero.setBackgroundResource(R.drawable.cocinero1);
                }
            }
        });

        btnsecretaria.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(secretaria==false){
                    secretaria=true;
                    btnsecretaria.setBackgroundResource(R.drawable.secretaria2);
                }
                else if(secretaria==true){
                    secretaria=false;
                    btnsecretaria.setBackgroundResource(R.drawable.secretaria1);
                }
            }
        });

        btnaudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                audio.start();
            }
        });

        btnsiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(alcalde==true && secretaria==true && cocinero==false && cartero==false && bombero==false){
                    audio.stop();
                   if(idioma.equals("castellano")){
                       Toast.makeText(getApplicationContext(),"Enhorabuena, has acertado", Toast.LENGTH_SHORT).show();
                   }
                   else{
                       Toast.makeText(getApplicationContext(),"Zorionak, lortu duzu", Toast.LENGTH_SHORT).show();
                   }
                    Intent i = new Intent(Ayuntamiento3.this,Maps.class);
                    i.putExtra("idioma",idioma);
                    i.putExtra("lugar", "ayunta");
                    startActivityForResult(i, REQUEST_SIGUIENTE);
                }
                else{
                    if(idioma.equals("castellano")){
                        Toast.makeText(getApplicationContext(),"Te has equivocado, prueba otra vez", Toast.LENGTH_SHORT).show();

                    }
                    else{
                        Toast.makeText(getApplicationContext(),"Txarto egin duzu, zaiatu berriro", Toast.LENGTH_SHORT).show();

                    }
                }
            }
        });

        btnanterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                audio.stop();
                Intent i = new Intent(Ayuntamiento3.this,Instrucciones2.class);
                i.putExtra("idioma",idioma);
                startActivityForResult(i, REQUEST_ANTERIOR);
            }
        });
    }

    public void parseJson (String s){
        TextView tvayunta = (TextView) findViewById(R.id.tvayunta);
        StringBuilder builder = new StringBuilder();
        try{
            JSONObject root = new JSONObject(s);
            JSONObject path = root.getJSONObject("ayuntamiento");
            if(idioma.equals("castellano")){
                builder.append(path.getString("textocastellano"));
            }
            else{
                builder.append(path.getString("textoeuskera"));
            }
        }catch(JSONException e){
            e.printStackTrace();
        }
        tvayunta.setText(builder.toString());
        StringBuilder builders = new StringBuilder();

        try{
            JSONObject root = new JSONObject(s);
            JSONObject path = root.getJSONObject("ayuntamiento");
            if(idioma.equals("castellano")){
                builders.append(path.getString("audiocastellano"));
            }
            else{
                builders.append(path.getString("audioeuskera"));
            }
        }catch(JSONException e){
            e.printStackTrace();
        }
        String sonido = builders.toString();
        int y = getResources().getIdentifier(sonido,"raw",this.getPackageName());
        audio=MediaPlayer.create(this,y);
        audio.start();

    }

    }







