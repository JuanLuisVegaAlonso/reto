package com.example.ik_2dm3.reto;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.MediaController;
import android.widget.VideoView;

import java.io.InputStream;
import java.util.Scanner;

import static com.example.ik_2dm3.reto.Bailefinal16.REQUEST_ANTERIOR;

public class Bailarin4Activity15 extends AppCompatActivity {

    private ImageButton butSiguiente;
    private ImageButton butAtras;
    public String idioma;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bailarin4);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        idioma = getIntent().getStringExtra("idioma");
        Resources res = getResources();
        InputStream is = res.openRawResource(R.raw.json);
        Scanner scanner = new Scanner(is);
        StringBuilder builder = new StringBuilder();
        while(scanner.hasNextLine()){
            builder.append(scanner.nextLine());
        }
        //parseJson(builder.toString());

        butSiguiente = findViewById(R.id.proximo);
        butAtras = findViewById(R.id.previo);


        butSiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Bailarin4Activity15.this, Bailefinal16.class);
                i.putExtra("idioma", idioma);
                startActivity(i);
            }
        });
        butAtras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Bailarin4Activity15.this, Bailarin3Activity14.class);
                i.putExtra("idioma", idioma);
                startActivityForResult(i, REQUEST_ANTERIOR);
            }
        });
        //obtenemos el control VideoView
        VideoView videoView = (VideoView)findViewById(R.id.vidUno);
        //Establecemos la Uri del Video
        Uri uri = Uri.parse("android.resource://"+getPackageName()+"/"+ R.raw.bailarin4);

        MediaController mc = new MediaController(this);
        videoView.setMediaController(mc);

        //Asignamos la Uri al COntrol VideoView
        videoView.setVideoURI(uri);
        //Iniciamos Video
        videoView.start();
    }
/*
    private void parseJson (String s){
        TextView txtbailarin4 = (TextView) findViewById(R.id.txtBailarin4);
        StringBuilder builder = new StringBuilder();
        try{
            JSONObject root = new JSONObject(s);
            JSONObject main = root.getJSONObject("estatua");
            if(idioma.equals("castellano")){
                builder.append(main.getString("textocastellano2"));
            }
            else{
                builder.append(main.getString("textoeuskera2"));
            }
        }catch(JSONException e){
            e.printStackTrace();
        }
        txtbailarin4.setText(builder.toString());
    }
    */
}
