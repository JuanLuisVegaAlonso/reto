package com.example.ik_2dm3.reto;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.Scanner;

import static com.example.ik_2dm3.reto.Bailefinal16.REQUEST_ANTERIOR;
import static com.example.ik_2dm3.reto.Bailefinal16.REQUEST_SIGUIENTE;

public class Deposito8 extends AppCompatActivity {

    private ImageButton butDibujo;
    private Button btnaudio;
    private ImageButton btnanterior;
    private ImageButton btnsiguiente;
    private TextView textDeposito;
    private ImageView imageInvisible;
    public String idioma;
    public MediaPlayer audio;
    private static final int REQUEST_DIBUJO = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deposito);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        idioma = getIntent().getStringExtra("idioma");

        Resources res = getResources();
        InputStream is = res.openRawResource(R.raw.json);
        Scanner scanner = new Scanner(is);
        StringBuilder builder = new StringBuilder();
        while(scanner.hasNextLine()){
            builder.append(scanner.nextLine());
        }
        parseJson(builder.toString());

        btnaudio = findViewById(R.id.btnaudio);
        butDibujo = findViewById(R.id.btnDibujo);
        btnanterior=findViewById(R.id.previo);
        btnsiguiente=findViewById(R.id.proximo);
        imageInvisible = findViewById(R.id.imgInvisible);
        textDeposito = findViewById(R.id.txtDeposito);


        butDibujo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Deposito8.this, DibujoActivity.class);
                i.putExtra("idioma", idioma);
                startActivityForResult(i, REQUEST_DIBUJO);
            }
        });

        btnaudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                audio.start();
            }
        });

        btnsiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                audio.stop();
                Intent i = new Intent(Deposito8.this, Maps.class);
                i.putExtra("idioma",idioma);
                i.putExtra("lugar","deposito");
                startActivityForResult(i, REQUEST_SIGUIENTE);
            }
        });

        btnanterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                audio.stop();
                Intent i = new Intent(Deposito8.this, Maps.class);
                i.putExtra("idioma",idioma);
                i.putExtra("lugar","iglesia");
                startActivityForResult(i, REQUEST_ANTERIOR);
            }
        });
    }

    private void parseJson (String s){
        TextView txtdeposito = (TextView) findViewById(R.id.txtDeposito);
        StringBuilder builder = new StringBuilder();
        try{
            JSONObject root = new JSONObject(s);
            JSONObject main = root.getJSONObject("deposito");
            if(idioma.equals("castellano")){
                builder.append(main.getString("textocastellano"));
            }
            else{
                builder.append(main.getString("textoeuskera"));
            }
        }catch(JSONException e){
            e.printStackTrace();
        }
        txtdeposito.setText(builder.toString());
        StringBuilder builders = new StringBuilder();

        try{
            JSONObject root = new JSONObject(s);
            JSONObject path = root.getJSONObject("deposito");
            if(idioma.equals("castellano")){
                builders.append(path.getString("audiocastellano"));
            }
            else{
                builders.append(path.getString("audioeuskera"));
            }
        }catch(JSONException e){
            e.printStackTrace();
        }
        String sonido = builders.toString();
        int y = getResources().getIdentifier(sonido,"raw",this.getPackageName());
        audio= MediaPlayer.create(this,y);
        audio.start();
    }
}
