package com.example.ik_2dm3.reto;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.VideoView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.Scanner;

public class Bailefinal16 extends AppCompatActivity {

    private ImageButton btnanterior;
    private ImageButton btnsiguiente;
    private Button btnvideo;
    public String idioma;
    private VideoView vv=null;

    static final int REQUEST_VIDEO_CAPTURE = 1;
    static final int REQUEST_SIGUIENTE = 0;
    static final int REQUEST_ANTERIOR = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bailefinal);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        idioma = getIntent().getStringExtra("idioma");

        Resources res = getResources();
        InputStream is = res.openRawResource(R.raw.json);
        Scanner scanner = new Scanner(is);
        StringBuilder builder = new StringBuilder();
        while(scanner.hasNextLine()){
            builder.append(scanner.nextLine());
        }
        parseJson(builder.toString());

        btnanterior=(ImageButton) findViewById(R.id.btnanterior);
        btnsiguiente=(ImageButton) findViewById(R.id.btnsiguiente);
        btnvideo=(Button) findViewById(R.id.btnvideo);
        vv = (VideoView) findViewById(R.id.vv);






        btnanterior.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Bailefinal16.this, Bailarin4Activity15.class);
                i.putExtra("idioma", idioma);
                startActivityForResult(i, REQUEST_ANTERIOR);
            }
        });

        btnvideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent takeVideoIntent = new Intent((MediaStore.ACTION_VIDEO_CAPTURE));
                if(takeVideoIntent.resolveActivity(getPackageManager()) != null){
                    startActivityForResult(takeVideoIntent, REQUEST_VIDEO_CAPTURE);
                }
            }
        });



    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        if (requestCode == REQUEST_VIDEO_CAPTURE && resultCode == RESULT_OK) {
            Uri videoUri = intent.getData();
            vv.setVideoURI(videoUri);
            btnsiguiente.setEnabled(true);
            btnsiguiente.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(Bailefinal16.this, Final.class);
                    i.putExtra("idioma", idioma);
                    startActivityForResult(i, REQUEST_SIGUIENTE);
                }
            });
        }
    }
    private void parseJson (String s){
        TextView tvbailefinal = (TextView) findViewById(R.id.tvbailefinal);
        StringBuilder builder = new StringBuilder();
        try{
            JSONObject root = new JSONObject(s);
            JSONObject main = root.getJSONObject("estatua");
            if(idioma.equals("castellano")){
                builder.append(main.getString("finalcastellano"));
            }
            else{
                builder.append(main.getString("finaleuskera"));
            }
        }catch(JSONException e){
            e.printStackTrace();
        }
        tvbailefinal.setText(builder.toString());
    }

}
