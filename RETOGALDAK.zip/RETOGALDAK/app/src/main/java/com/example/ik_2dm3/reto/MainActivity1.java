package com.example.ik_2dm3.reto;

import android.Manifest;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;


public class MainActivity1 extends AppCompatActivity {

    private Button btnJugar;
    public String idioma;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        Resources res = getResources();
        InputStream is = res.openRawResource(R.raw.json);
        Scanner scanner = new Scanner(is);
        StringBuilder builder = new StringBuilder();
        while(scanner.hasNextLine()){
            builder.append(scanner.nextLine());
        }
        parseJson(builder.toString());

        // Si la versión del Android es anterior al 6.0 (así sería suficiente con configurar el archivo manifest) o es superior y los permisos ya están dados, lo ejecutamos normal
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)) {
            // El código que queramos ejecutar en caso de tener permisos
        }
        // Si estamos en un Android 6.0 o superior y no tenemos permisos, los pedimos (y allí ejecutaremos el comando a ejecutar después de obtener los permisos)
        else {
            // Pedimos permisos al usuario para la localización precisa (GPS) y escritura externa (en microSD)
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 123);



        }




        btnJugar = (Button) findViewById(R.id.btnJugar);
        Button btnJolastu = (Button) findViewById(R.id.btnJolastu);


        btnJugar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                idioma = "castellano";
                Intent i = new Intent(MainActivity1.this, Instrucciones2.class);
                i.putExtra("idioma","castellano");
                startActivity(i);
            }
        });
        btnJolastu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                idioma = "euskera";
                Intent i = new Intent(MainActivity1.this, Instrucciones2.class);
                i.putExtra("idioma","euskera");
                startActivity(i);
            }
        });
    }

    private void parseJson(String s) {
        Button btnJolastu = (Button) findViewById(R.id.btnJolastu);
        btnJugar = (Button) findViewById(R.id.btnJugar);

        StringBuilder builderc = new StringBuilder();
        try {
            JSONObject root = new JSONObject(s);
            JSONObject main = root.getJSONObject("main");
            builderc.append(main.getString("euskera"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        btnJolastu.setText(builderc.toString());
        StringBuilder buildere = new StringBuilder();
        try {
            JSONObject root = new JSONObject(s);
            JSONObject main = root.getJSONObject("main");
            buildere.append(main.getString("castellano"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        btnJugar.setText(buildere.toString());
    }

        @Override
        public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
            // Si la respuesta proviene de la petición de permisos que hemos creado antes (vincula a través del ID 123)
            if (requestCode == 123) {
                // Si el usuario ha dado permis
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED)
                {
                    // Obtenemos nuestra ubicación
                    Toast.makeText(this, "El usuario ha dado permisos! " + Build.VERSION.SDK_INT, Toast.LENGTH_LONG).show();
                }
                // Si los ha rechazado
                else {
                    Toast.makeText(this, "Permisos no otorgados! 🙁 " + Build.VERSION.SDK_INT, Toast.LENGTH_LONG).show();
                }
            }
            // En caso de que la respuesta de permisos no sea el que nosotros hemos definido
            else {
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            }
    }
}
